﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Nakov.TurtleGraphics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace fluffyBird
{
    public partial class Form1 : Form
    {
        public int birdW = 17;
        public int birdH = 12;
        public int[] Coll1 = { 120, 220 }; //X colls, hight of first one
        public int[] Coll2 = { 340, 70 };
        public int velocity = 0;
        public int g = -4;
        public int GapSize = 70;
        public int MaxV = 40;
        public int MaxH = 200; //max board hieght
        public int[] pos = { -100, 100 };
        public int score = 0;
        public Random rand = new Random();


        public string[,] bird = {
            {"0", "0", "0", "0", "0", "0", "B", "B", "B", "B", "B", "B", "0", "0", "0", "0", "0" },
            {"0", "0", "0", "0", "B", "B", "Y", "Y", "Y", "Y", "B", "W", "B", "0", "0", "0", "0" },
            {"0", "0", "0", "B", "Y", "Y", "Y", "Y", "Y", "B", "W", "W", "W", "B", "0", "0", "0" },
            {"0", "B", "B", "B", "B", "Y", "Y", "Y", "Y", "Y", "W", "W", "B", "W", "B", "0", "0" },
            {"B", "W", "W", "W", "W", "B", "Y", "Y", "Y", "B", "W", "W", "B", "W", "B", "0", "0" },
            {"B", "W", "W", "W", "W", "W", "B", "Y", "Y", "Y", "B", "W", "W", "W", "B", "0", "0" },
            {"B", "W", "W", "W", "W", "W", "B", "Y", "Y", "Y", "Y", "B", "B", "B", "B", "B", "0" },
            {"0", "B", "W", "W", "W", "B", "Y", "Y", "Y", "Y", "B", "O", "O", "O", "O", "O", "B" },
            {"0", "0", "B", "B", "B", "Y", "Y", "Y", "Y", "B", "O", "B", "B", "B", "B", "B", "0" }, 
            {"0", "0", "0", "0", "B", "Y", "Y", "Y", "Y", "Y", "B", "O", "O", "O", "O", "B", "0" },
            {"0", "0", "0", "0", "0", "B", "B", "Y", "Y", "Y", "Y", "B", "B", "B", "B", "B", "0" },
            {"0", "0", "0", "0", "0", "0", "0", "B", "B", "B", "B", "0", "0", "0", "0", "0", "0" }};
        
        public Form1()
        {
            InitializeComponent();
            timer1.Start();
        }
        private void DrawBird()
        {
            Turtle.ShowTurtle = false;
            Turtle.PenSize = 1;
            Turtle.Delay = 0;
            for (int i = 0; i < birdH; i++)
            {
                for (int j = 0; j < birdW; j++)
                {
                    if (!(bird[i, j] == "0"))
                    {
                        if (bird[i, j] == "B") Turtle.PenColor = Color.Black;
                        else if (bird[i, j] == "W") Turtle.PenColor = Color.White;
                        else if (bird[i, j] == "O") Turtle.PenColor = Color.Orange;
                        else Turtle.PenColor = Color.Yellow;

                        Turtle.PenUp();
                        Turtle.MoveTo(pos[0] + 2 * j, pos[1] - 2 * i);
                        Turtle.PenDown();
                        for (int k = 0; k < 4; k++)
                        {
                            Turtle.Forward(1);
                            Turtle.Rotate(90);
                        }
                    }
                }
            }
        }
        private void DrawColl(int CollX, int CollH)
        {
            Turtle.PenColor = Color.Green;
            for (int i = -200; i < CollH - 220; i++)
            {
                Turtle.RotateTo(90);
                Turtle.PenUp();
                Turtle.MoveTo(CollX, i);
                Turtle.PenDown();
                Turtle.Forward(40);
            }
            for(int i = CollH - 220; i < CollH - 200; i++)
            {
                Turtle.RotateTo(90);
                Turtle.PenUp();
                Turtle.MoveTo(CollX - 5, i);
                Turtle.PenDown();
                Turtle.Forward(50);
            }
            for (int i = CollH + GapSize - 200; i < CollH + GapSize - 180; i++)
            {
                Turtle.RotateTo(90);
                Turtle.PenUp();
                Turtle.MoveTo(CollX - 5, i);
                Turtle.PenDown();
                Turtle.Forward(50);
            }
            for (int i = CollH + GapSize - 180; i < MaxH; i++)
            {
                Turtle.RotateTo(90);
                Turtle.PenUp();
                Turtle.MoveTo(CollX, i);
                Turtle.PenDown();
                Turtle.Forward(40);
            }
        }

        private void DrawCloud(int x, int y)
        {
            Turtle.PenColor = Color.Gray;
            Turtle.PenSize = 3;
            for (int i = 0; i < 30; i++)
            {
                Turtle.PenUp();
                Turtle.MoveTo(x + rand.Next(-20, 20), y - i);
                Turtle.PenDown();
                Turtle.RotateTo(90);
                Turtle.Forward(rand.Next(60, 80));
            }

        }

        private void DrawGrass()
        {
            Turtle.PenUp();
            Turtle.PenColor = Color.LawnGreen;
            for(int i = 0; i < 10; i++)
            {
                Turtle.PenUp();
                Turtle.MoveTo(-200, -180+i);
                Turtle.RotateTo(90);
                Turtle.PenDown();
                Turtle.Forward(400);

            }
        }

        private void DrawSky()
        {
            Turtle.PenUp();
            Turtle.PenColor = Color.LightBlue;
            for (int i = 0; i < 400; i++)
            {
                Turtle.PenUp();
                Turtle.MoveTo(-200, -180 + i);
                Turtle.RotateTo(90);
                Turtle.PenDown();
                Turtle.Forward(400);

            }
        }

        private void DrawBackgrond()
        {
            DrawSky();
            DrawCloud(70, -120);
            DrawCloud(150, 50);
            DrawCloud(-150, 120);
            DrawGrass();

        }

        private void DrawTal()
        {
            Turtle.PenSize = 3;
            Turtle.PenUp();
            Turtle.MoveTo(150, 150);
            Turtle.PenDown();
            Turtle.PenColor = Color.Black;
            //T
            Turtle.RotateTo(90);
            Turtle.Forward(10);
            Turtle.PenUp();
            Turtle.MoveTo(155, 150);
            Turtle.PenDown();
            Turtle.RotateTo(180);
            Turtle.Forward(10);
            //A
            Turtle.PenUp();
            Turtle.MoveTo(170, 150);
            Turtle.PenDown();
            Turtle.MoveTo(165, 140);
            Turtle.MoveTo(170, 150);
            Turtle.MoveTo(175, 140);
            Turtle.PenUp();
            Turtle.MoveTo(168, 145);
            Turtle.PenDown();
            Turtle.RotateTo(90);
            Turtle.Forward(4);
            //L
            Turtle.PenUp();
            Turtle.MoveTo(180, 150);
            Turtle.PenDown();
            Turtle.RotateTo(180);
            Turtle.Forward(10);
            Turtle.RotateTo(90);
            Turtle.Forward(10);
            Turtle.PenSize = 1;
        }

        private void DrawBoard()
        {
            DrawBackgrond();
            DrawBird();
            DrawColl(Coll1[0], Coll1[1]);
            DrawColl(Coll2[0], Coll2[1]);
            if (Coll1[0] < -240)
            {
                Coll1[0] = 200;
                Coll1[1] = rand.Next(100, 300);
                score++;
            }
            if (Coll2[0] < -240)
            {
                Coll2[0] = 200;
                Coll2[1] = rand.Next(100, 300);
                score++;
            }
            DrawTal();
        }

        private void GameOver()
        {
            timer1.Stop();
            MessageBox.Show("your score was: " + Convert.ToString(score));
            score = 0;
            pos[1] = 100;
            Coll1[0] = 120;
            Coll2[0] = 340;
            velocity = 0;
            timer1.Start();
        }

        private bool CheckColl(int CollX, int CollH)
        {
            if (pos[0] + birdW*2 > CollX - 5 && pos[0] < CollX + 45)
            {
                if (pos[1] - birdH*2 < CollH - 200 || pos[1] > CollH + GapSize - 200)
                {
                    return true;
                }
            }
            return false;
        }
        private bool Pasool()
        {
            if (CheckColl(Coll1[0], Coll1[1])) return true;
            if (CheckColl(Coll2[0], Coll2[1])) return true;
            if (pos[1] > 400 - 200 || pos[1] < 24 - 200) return true;
            return false;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            Turtle.PenSize = 1;
            Turtle.PenColor = Color.White;
            for (int i = -200; i < 200; i++)
            {
                Turtle.MoveTo(-200, i);
                Turtle.RotateTo(90);
                Turtle.Forward(400);
            }
            if (Pasool())
            {
                GameOver();
            }
            velocity += g;
            pos[1] += velocity;
            Coll1[0] -= 4;
            Coll2[0] -= 4;
            DrawBoard();
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Space)
            {
                if (velocity < MaxV) velocity += 20;
            }
        }

        private void Form1_AutoSizeChanged(object sender, EventArgs e)
        {

        }
    }
}
