﻿using System;
using Nakov.TurtleGraphics;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace SNAKE
{
    public partial class Form1 : Form
    {
        public int[] position = { 0, 0 };
        public static Random rnd = new Random();
        public int[] food = {70, -70};
        public int[,] snakearr = new int[40000, 2];
        public int snakeSize = 2;
        public int score = 0;

        public Form1()
        {
            InitializeComponent();
            timer1.Start();
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            
            if (e.KeyChar == (char)Keys.W) position[1] += 1;
            else if (e.KeyChar == (char)Keys.D) position[0] += 1;
            else if (e.KeyChar == (char)Keys.S) position[1] -= 1;
            else if (e.KeyChar == (char)Keys.A) position[0] -= 1;
        }
        private void updateSnake()
        {
            int[] temp = new int[2];
            if (snakearr[0, 0] == position[0] && snakearr[0, 1] == position[1])
            {
                temp[0] = snakearr[1, 0];
                temp[1] = snakearr[1, 1];
                for (int i = snakeSize - 1; i > 0; i--)
                {
                    snakearr[i, 0] = snakearr[i - 1, 0];
                    snakearr[i, 1] = snakearr[i - 1, 1];
                }

                if (snakearr[0, 0] > temp[0]) snakearr[0, 0] += 1;
                else if(snakearr[0, 0] < temp[0]) snakearr[0, 0] -= 1;
                else if (snakearr[0, 1] < temp[1]) snakearr[0, 1] -= 1;
                else snakearr[0, 1] += 1;
                position[0] = snakearr[0, 0];
                position[1] = snakearr[0, 1];
            }
            else
            {
                for (int i = snakeSize - 1; i > 0; i--)
                {
                    snakearr[i, 0] = snakearr[i - 1, 0];
                    snakearr[i, 1] = snakearr[i - 1, 1];
                }
                snakearr[0, 0] = position[0];
                snakearr[0, 1] = position[1];
            }
        }
        private void drawFood()
        {
            Turtle.PenColor = Color.Red;
            Turtle.PenUp();
            Turtle.MoveTo(food[0], food[1]);
            Turtle.PenDown();
            Turtle.Forward(1);
        }
        private void drawsnake()
        {
            Turtle.PenColor = Color.Green;
            Turtle.PenUp();
            Turtle.MoveTo(6 * snakearr[0, 0], 6 * snakearr[0, 1]);
            Turtle.PenDown();
            for (int i = 0; i < snakeSize; i++)
            {
                Turtle.MoveTo(6 * snakearr[i, 0], 6 * snakearr[i, 1]);
            }
        }
        private void draw_sides()
        {
            Turtle.PenUp();
            Turtle.MoveTo(100, 100);
            Turtle.PenDown();
            Turtle.PenColor = Color.Black;
            Turtle.RotateTo(-90);
            for(int i = 0; i < 4; i++)
            {
                Turtle.Forward(200);
                Turtle.Rotate(-90);
            }
        }
        private void drawboard()
        {
            Turtle.Reset();
            Turtle.ShowTurtle = false;
            draw_sides();
            drawFood();
            drawsnake();
        }
        private void checkApple()
        {
            if (food[0] <= (6 * position[0] + 5) && food[0] >= (6 * position[0] - 5))
            {
                if (food[1] <= (6 * position[1] + 5) && food[1] >= (6 * position[1] - 5))
                {
                    snakeSize++;
                    food[0] = rnd.Next(-90, 90);
                    food[1] = rnd.Next(-90, 90);
                    score++;
                }
            }
        }

        private bool valid()
        {
            if (6*Math.Abs(position[0]) > 95 || 6*Math.Abs(position[1]) > 95) return false;
            for (int i = 2; i < snakeSize; i++)
            {
                if(snakearr[0, 0] == snakearr[i, 0] && snakearr[0, 1] == snakearr[i, 1]) { return false; } 
            }
            return true;
        }
        private void resetgame()
        {
            score = 0;
            snakeSize = 2;
            for (int i = 0; i < 40000; i++)
            {
                snakearr[i, 0] = 0;
                snakearr[i, 1] = 0;
            }
            position[0] = 0;
            position[1] = 1;
            Turtle.Reset();
            Turtle.ShowTurtle = false;
            Turtle.PenColor = Color.Green;
            timer1.Start();
        }
        private void gameOver()
        {
            timer1.Stop();
            string title = "Close Window";
            MessageBoxButtons buttons = MessageBoxButtons.OK;
            DialogResult result = MessageBox.Show("your score is: " + Convert.ToString(score) + "\n reset game? ", title, buttons);
            resetgame();
            
        }
        private void checkCaps()
        {
            bool isCapsLockToggled = Control.IsKeyLocked(Keys.CapsLock);
            if (!isCapsLockToggled)
            {
                timer1.Stop();
                MessageBox.Show("please toggle caps loock");
                while (isCapsLockToggled)
                {
                    isCapsLockToggled = Control.IsKeyLocked(Keys.CapsLock);
                }
                timer1.Start();
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            checkCaps();
            if (!valid()) { gameOver(); }
            checkApple();
            updateSnake();
            drawboard();
        }

    }
}
